# odk3_fsbl
Custom version of the Xilinx FSBL for ODK3. NOTE as this project has been created by the vitis 'Platform' project tool includes BSP & pmufw. It is not intended for this platform to be used by downstream tools other than to provide fsbl .elf files.

All customations are bounded by the tag `// OPT_MOD begin / end`

NOTE the .xsa and all HW in this project does not and **MUST NOT** contain any IP - just a template design to provide psu_init.

List of modifications to the base FSBL....

## USB PHY reset
performed in xfsbl_board.c / XFsbl_BoardInit
ULPI_RST - USB Phy RSTn on MIO77 is pulsed low
