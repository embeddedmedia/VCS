#include <msp430.h> 


// Port allocation
//
// P1.1     BOOTSEL0            i/p
// P1.2     BOOTSEL1            i/p
// P1.3     EXT_TO_TYC_SW_EN    i/p
// P1.4     RESET_INn           i/p
// P3.0     SDA                 i/o
// P3.1     SCL                 i/o
// P4.1     CLKGEN_OE           o/p
// P4.4     BMODE0              o/p
// P4.6     BMODE1              o/p
// P5.1     SYS_CTRL_1
// P5.3     PG_DDR_Reg          i/p
// P5.5     EN_MGT              o/p
// P6.0     PGOOD               o/p
// P6.6     CON_DET             i/p
// P6.7     SYS_CTRL_0
// P7.0     BMODE2              o/p
// P7.1     ZYNQ_RSTn           o/p
// P7.3     BMODE3              o/p
// PJ.0     PG_MGT_Reg          i/p
// PJ.1     BOOT_MODE_LED       o/p

/*
 * main.c
 */
int main(void)
{
    int dly=0;
    int rst_in, bootsel0;

    WDTCTL = WDTPW | WDTHOLD;	// stop watchdog timer

// P4.1 <= 0                        CLKGEN_OE = enabled
// P4.4, P4.6, P7.0, P7.3 <= 0000   BMODE=0000
// P5.5 <= 1                        EN_MGT = enabled
// P6.0 <= 1                        PGODD = 1, LED ON
// P7.1 <= P1.4                     ZYNQ_RSTn follows RESET_INn
// PJ.1 <= 1                        BOOT_MODE_LED = 1, LED ON

    P1DIR  = 0b00000000;
    P4DIR |= 0b01010010;
    P5DIR |= 0b00100000;
    P6DIR |= 0b00000001;
	P7DIR |= 0b00001011;
    PJDIR |= 0b00000010;

    P4OUT  = 0b00000000;            // BMODE0,1=00
	P7OUT  = 0b00000010;            // Zynq RST is o/p. BMODE2,3=00
	P5OUT  = 0b00100000;            // Enable MGT rails, bit 5=1
	P6OUT  = 0b00000001;            // PGOOD LED = ON
	PJOUT  = 0b00000010;            // BOOT MODE LED = ON

	while(1) {
	    dly++;
	    if(dly == 10000) {
	        P6OUT=0;
	        PJOUT=0;
	    }
	    if(dly == 20000) {
	        dly=0;
	        P6OUT=1;
	        PJOUT=2;
	    }
	    rst_in = (P1IN & 0b00010000) >>4;
	    if(rst_in == 0) P7OUT &= 0b11111101;
	    else            P7OUT |= 0b00000010;

	    bootsel0 = (P1IN & 0b00000010) >>1;
	    if(bootsel0 == 0) P4OUT &= 0b11101111;
	    else              P4OUT |= 0b00010000;
	}
	return 0;
}
